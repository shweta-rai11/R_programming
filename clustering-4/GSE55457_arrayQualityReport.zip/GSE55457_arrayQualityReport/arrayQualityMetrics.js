// (C) Wolfgang Huber 2010-2011

// Script parameters - these are set up by R in the function 'writeReport' when copying the 
//   template for this script from arrayQualityMetrics/inst/scripts into the report.

var highlightInitial = [ false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false ];
var arrayMetadata    = [ [ "1", "GSM1337304", "Normal, synovial membrane patient EB_125 (U133A)", "gender: male", "age: 61", "clinical status: normal control", "none", "61", "normal control", "male" ], [ "2", "GSM1337305", "Normal, synovial membrane patient EB_184 (U133A)", "gender: male", "age: 64", "clinical status: normal control", "none", "64", "normal control", "male" ], [ "3", "GSM1337306", "Normal, synovial membrane patient EB_188 (U133A)", "gender: female", "age: 78", "clinical status: normal control", "none", "78", "normal control", "female" ], [ "4", "GSM1337307", "Normal, synovial membrane patient EB_228 (U133A)", "gender: male", "age: 65", "clinical status: normal control", "none", "65", "normal control", "male" ], [ "5", "GSM1337308", "Normal, synovial membrane patient J_19 (U133A)", "gender: male", "age: 53", "clinical status: normal control", "none", "53", "normal control", "male" ], [ "6", "GSM1337309", "Normal, synovial membrane patient NST_1 (U133A)", "gender: male", "age: 68", "clinical status: normal control", "none", "68", "normal control", "male" ], [ "7", "GSM1337310", "Normal, synovial membrane patient J_2 (U133A)", "gender: female", "age: 29", "clinical status: normal control", "none", "29", "normal control", "female" ], [ "8", "GSM1337311", "Normal, synovial membrane patient J_6 (U133A)", "gender: male", "age: 17", "clinical status: normal control", "none", "17", "normal control", "male" ], [ "9", "GSM1337312", "Normal, synovial membrane patient J_7 (U133A)", "gender: male", "age: 39", "clinical status: normal control", "none", "39", "normal control", "male" ], [ "10", "GSM1337313", "Normal, synovial membrane patient J_12 (U133A)", "gender: male", "age: 36", "clinical status: normal control", "none", "36", "normal control", "male" ], [ "11", "GSM1337314", "Rheumatoid arthritis, synovial membrane patient EB_20 (U133A)", "gender: male", "age: 75", "clinical status: rheumatoid arthritis", "NSARD, azulfidine, prednisolone", "75", "rheumatoid arthritis", "male" ], [ "12", "GSM1337315", "Rheumatoid arthritis, synovial membrane patient EB_27 (U133A)", "gender: female", "age: 79", "clinical status: rheumatoid arthritis", "NSARD, prednisolone, MTX", "79", "rheumatoid arthritis", "female" ], [ "13", "GSM1337316", "Rheumatoid arthritis, synovial membrane patient EB_30 (U133A)", "gender: female", "age: 63", "clinical status: rheumatoid arthritis", "NSARD, prednisolone, MTX", "63", "rheumatoid arthritis", "female" ], [ "14", "GSM1337317", "Rheumatoid arthritis, synovial membrane patient EB_35 (U133A)", "gender: female", "age: 66", "clinical status: rheumatoid arthritis", "NSARD, azulfidine, prednisolone, MTX", "66", "rheumatoid arthritis", "female" ], [ "15", "GSM1337318", "Rheumatoid arthritis, synovial membrane patient EB_40 (U133A)", "gender: female", "age: 64", "clinical status: rheumatoid arthritis", "NSARD, prednisolone, MTX", "64", "rheumatoid arthritis", "female" ], [ "16", "GSM1337319", "Rheumatoid arthritis, synovial membrane patient EB_41 (U133A)", "gender: female", "age: 63", "clinical status: rheumatoid arthritis", "NSARD, azulfidine, prednisolone", "63", "rheumatoid arthritis", "female" ], [ "17", "GSM1337320", "Rheumatoid arthritis, synovial membrane patient EB_56 (U133A)", "gender: female", "age: 46", "clinical status: rheumatoid arthritis", "prednisolone, MTX", "46", "rheumatoid arthritis", "female" ], [ "18", "GSM1337321", "Rheumatoid arthritis, synovial membrane patient EB_74 (U133A)", "gender: female", "age: 71", "clinical status: rheumatoid arthritis", "NSARD", "71", "rheumatoid arthritis", "female" ], [ "19", "GSM1337322", "Rheumatoid arthritis, synovial membrane patient EB_108 (U133A)", "gender: female", "age: 72", "clinical status: rheumatoid arthritis", "NSARD, prednisolone", "72", "rheumatoid arthritis", "female" ], [ "20", "GSM1337323", "Rheumatoid arthritis, synovial membrane patient EB_109 (U133A)", "gender: female", "age: 2", "clinical status: rheumatoid arthritis", "none", "2", "rheumatoid arthritis", "female" ], [ "21", "GSM1337324", "Rheumatoid arthritis, synovial membrane patient EB_110 (U133A)", "gender: male", "age: 47", "clinical status: rheumatoid arthritis", "NSARD, prednisolone", "47", "rheumatoid arthritis", "male" ], [ "22", "GSM1337325", "Rheumatoid arthritis, synovial membrane patient EB_124 (U133A)", "gender: male", "age: 59", "clinical status: rheumatoid arthritis", "COX-2 inhibitor, prednisolone, quensyl", "59", "rheumatoid arthritis", "male" ], [ "23", "GSM1337326", "Rheumatoid arthritis, synovial membrane patient EB_141 (U133A)", "gender: female", "age: 73", "clinical status: rheumatoid arthritis", "NSAID, prednisolone, Tilidin", "73", "rheumatoid arthritis", "female" ], [ "24", "GSM1337327", "Osteoarthritis, synovial membrane patient EB_21 (U133A)", "gender: female", "age: 77", "clinical status: osteoarthritis", "none", "77", "osteoarthritis", "female" ], [ "25", "GSM1337328", "Osteoarthritis, synovial membrane patient EB_24 (U133A)", "gender: female", "age: 71", "clinical status: osteoarthritis", "NSARD", "71", "osteoarthritis", "female" ], [ "26", "GSM1337329", "Osteoarthritis, synovial membrane patient EB_54 (U133A)", "gender: female", "age: 76", "clinical status: osteoarthritis", "NSARD", "76", "osteoarthritis", "female" ], [ "27", "GSM1337330", "Osteoarthritis, synovial membrane patient EB_90 (U133A)", "gender: female", "age: 61", "clinical status: osteoarthritis", "none", "61", "osteoarthritis", "female" ], [ "28", "GSM1337331", "Osteoarthritis, synovial membrane patient EB_94 (U133A)", "gender: female", "age: 75", "clinical status: osteoarthritis", "NSARD", "75", "osteoarthritis", "female" ], [ "29", "GSM1337332", "Osteoarthritis, synovial membrane patient EB_97 (U133A)", "gender: male", "age: 78", "clinical status: osteoarthritis", "NSARD, prednisolone, MTX", "78", "osteoarthritis", "male" ], [ "30", "GSM1337333", "Osteoarthritis, synovial membrane patient EB_99 (U133A)", "gender: male", "age: 69", "clinical status: osteoarthritis", "NSARD", "69", "osteoarthritis", "male" ], [ "31", "GSM1337334", "Osteoarthritis, synovial membrane patient EB_100 (U133A)", "gender: female", "age: 71", "clinical status: osteoarthritis", "NSARD", "71", "osteoarthritis", "female" ], [ "32", "GSM1337335", "Osteoarthritis, synovial membrane patient EB_104 (U133A)", "gender: female", "age: 80", "clinical status: osteoarthritis", "NSARD", "80", "osteoarthritis", "female" ], [ "33", "GSM1337336", "Osteoarthritis, synovial membrane patient EB_140 (U133A)", "gender: female", "age: 66", "clinical status: osteoarthritis", "NSAID", "66", "osteoarthritis", "female" ] ];
var svgObjectNames   = [ "pca", "dens" ];

var cssText = ["stroke-width:1; stroke-opacity:0.4",
               "stroke-width:3; stroke-opacity:1" ];

// Global variables - these are set up below by 'reportinit'
var tables;             // array of all the associated ('tooltips') tables on the page
var checkboxes;         // the checkboxes
var ssrules;


function reportinit() 
{
 
    var a, i, status;

    /*--------find checkboxes and set them to start values------*/
    checkboxes = document.getElementsByName("ReportObjectCheckBoxes");
    if(checkboxes.length != highlightInitial.length)
	throw new Error("checkboxes.length=" + checkboxes.length + "  !=  "
                        + " highlightInitial.length="+ highlightInitial.length);
    
    /*--------find associated tables and cache their locations------*/
    tables = new Array(svgObjectNames.length);
    for(i=0; i<tables.length; i++) 
    {
        tables[i] = safeGetElementById("Tab:"+svgObjectNames[i]);
    }

    /*------- style sheet rules ---------*/
    var ss = document.styleSheets[0];
    ssrules = ss.cssRules ? ss.cssRules : ss.rules; 

    /*------- checkboxes[a] is (expected to be) of class HTMLInputElement ---*/
    for(a=0; a<checkboxes.length; a++)
    {
	checkboxes[a].checked = highlightInitial[a];
        status = checkboxes[a].checked; 
        setReportObj(a+1, status, false);
    }

}


function safeGetElementById(id)
{
    res = document.getElementById(id);
    if(res == null)
        throw new Error("Id '"+ id + "' not found.");
    return(res)
}

/*------------------------------------------------------------
   Highlighting of Report Objects 
 ---------------------------------------------------------------*/
function setReportObj(reportObjId, status, doTable)
{
    var i, j, plotObjIds, selector;

    if(doTable) {
	for(i=0; i<svgObjectNames.length; i++) {
	    showTipTable(i, reportObjId);
	} 
    }

    /* This works in Chrome 10, ssrules will be null; we use getElementsByClassName and loop over them */
    if(ssrules == null) {
	elements = document.getElementsByClassName("aqm" + reportObjId); 
	for(i=0; i<elements.length; i++) {
	    elements[i].style.cssText = cssText[0+status];
	}
    } else {
    /* This works in Firefox 4 */
    for(i=0; i<ssrules.length; i++) {
        if (ssrules[i].selectorText == (".aqm" + reportObjId)) {
		ssrules[i].style.cssText = cssText[0+status];
		break;
	    }
	}
    }

}

/*------------------------------------------------------------
   Display of the Metadata Table
  ------------------------------------------------------------*/
function showTipTable(tableIndex, reportObjId)
{
    var rows = tables[tableIndex].rows;
    var a = reportObjId - 1;

    if(rows.length != arrayMetadata[a].length)
	throw new Error("rows.length=" + rows.length+"  !=  arrayMetadata[array].length=" + arrayMetadata[a].length);

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = arrayMetadata[a][i];
}

function hideTipTable(tableIndex)
{
    var rows = tables[tableIndex].rows;

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = "";
}


/*------------------------------------------------------------
  From module 'name' (e.g. 'density'), find numeric index in the 
  'svgObjectNames' array.
  ------------------------------------------------------------*/
function getIndexFromName(name) 
{
    var i;
    for(i=0; i<svgObjectNames.length; i++)
        if(svgObjectNames[i] == name)
	    return i;

    throw new Error("Did not find '" + name + "'.");
}


/*------------------------------------------------------------
  SVG plot object callbacks
  ------------------------------------------------------------*/
function plotObjRespond(what, reportObjId, name)
{

    var a, i, status;

    switch(what) {
    case "show":
	i = getIndexFromName(name);
	showTipTable(i, reportObjId);
	break;
    case "hide":
	i = getIndexFromName(name);
	hideTipTable(i);
	break;
    case "click":
        a = reportObjId - 1;
	status = !checkboxes[a].checked;
	checkboxes[a].checked = status;
	setReportObj(reportObjId, status, true);
	break;
    default:
	throw new Error("Invalid 'what': "+what)
    }
}

/*------------------------------------------------------------
  checkboxes 'onchange' event
------------------------------------------------------------*/
function checkboxEvent(reportObjId)
{
    var a = reportObjId - 1;
    var status = checkboxes[a].checked;
    setReportObj(reportObjId, status, true);
}


/*------------------------------------------------------------
  toggle visibility
------------------------------------------------------------*/
function toggle(id){
  var head = safeGetElementById(id + "-h");
  var body = safeGetElementById(id + "-b");
  var hdtxt = head.innerHTML;
  var dsp;
  switch(body.style.display){
    case 'none':
      dsp = 'block';
      hdtxt = '-' + hdtxt.substr(1);
      break;
    case 'block':
      dsp = 'none';
      hdtxt = '+' + hdtxt.substr(1);
      break;
  }  
  body.style.display = dsp;
  head.innerHTML = hdtxt;
}
