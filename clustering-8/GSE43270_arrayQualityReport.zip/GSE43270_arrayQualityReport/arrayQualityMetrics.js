// (C) Wolfgang Huber 2010-2011

// Script parameters - these are set up by R in the function 'writeReport' when copying the 
//   template for this script from arrayQualityMetrics/inst/scripts into the report.

var highlightInitial = [ false, false, false, false, false, false, true, true, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false ];
var arrayMetadata    = [ [ "1", "GSM1058094", "cartilage knee 10SE191_2", "disease state: osteoarthritis", "age: 45", "Sex: Male", "haplogroup: H", "45", "H", "Male" ], [ "2", "GSM1058095", "cartilage knee 10SE216", "disease state: osteoarthritis", "age: 67", "Sex: Female", "haplogroup: T", "67", "T", "Female" ], [ "3", "GSM1058096", "cartilage knee 10SE358", "disease state: osteoarthritis", "age: 65", "Sex: Female", "haplogroup: T", "65", "T", "Female" ], [ "4", "GSM1058097", "cartilage knee 10SE218", "disease state: osteoarthritis", "age: 73", "Sex: Female", "haplogroup: U", "73", "U", "Female" ], [ "5", "GSM1058098", "cartilage knee 10SE219", "disease state: osteoarthritis", "age: 80", "Sex: Male", "haplogroup: U", "80", "U", "Male" ], [ "6", "GSM1058099", "cartilage knee 10SE220", "disease state: osteoarthritis", "age: 66", "Sex: Male", "haplogroup: U", "66", "U", "Male" ], [ "7", "GSM1058100", "cartilage knee 10SE225", "disease state: osteoarthritis", "age: 74", "Sex: Female", "haplogroup: H", "74", "H", "Female" ], [ "8", "GSM1058101", "cartilage knee 10SE226", "disease state: osteoarthritis", "age: 84", "Sex: Male", "haplogroup: H", "84", "H", "Male" ], [ "9", "GSM1058102", "cartilage knee 10SE227", "disease state: osteoarthritis", "age: 73", "Sex: Female", "haplogroup: H", "73", "H", "Female" ], [ "10", "GSM1058103", "cartilage knee 10SE229", "disease state: osteoarthritis", "age: 75", "Sex: Female", "haplogroup: H", "75", "H", "Female" ], [ "11", "GSM1058104", "cartilage knee 10SE357", "disease state: osteoarthritis", "age: 70", "Sex: Male", "haplogroup: U", "70", "U", "Male" ], [ "12", "GSM1058105", "cartilage knee 10SE207", "disease state: osteoarthritis", "age: 74", "Sex: Female", "haplogroup: J", "74", "J", "Female" ], [ "13", "GSM1058106", "cartilage knee 10SE208", "disease state: osteoarthritis", "age: 80", "Sex: Female", "haplogroup: J", "80", "J", "Female" ], [ "14", "GSM1058107", "cartilage knee 10SE209", "disease state: osteoarthritis", "age: 63", "Sex: Female", "haplogroup: J", "63", "J", "Female" ], [ "15", "GSM1058108", "cartilage knee 10SE210", "disease state: osteoarthritis", "age: 64", "Sex: Female", "haplogroup: J", "64", "J", "Female" ], [ "16", "GSM1058109", "cartilage knee 10SE211", "disease state: osteoarthritis", "age: 74", "Sex: Female", "haplogroup: J", "74", "J", "Female" ], [ "17", "GSM1058110", "cartilage knee 10SE223", "disease state: osteoarthritis", "age: 60", "Sex: Female", "haplogroup: U", "60", "U", "Female" ], [ "18", "GSM1058111", "cartilage knee 10SE360", "disease state: osteoarthritis", "age: 56", "Sex: Female", "haplogroup: J", "56", "J", "Female" ], [ "19", "GSM1058112", "cartilage knee 10SE212", "disease state: osteoarthritis", "age: 73", "Sex: Female", "haplogroup: T", "73", "T", "Female" ], [ "20", "GSM1058113", "cartilage knee 10SE213", "disease state: osteoarthritis", "age: 79", "Sex: Female", "haplogroup: T", "79", "T", "Female" ], [ "21", "GSM1058114", "cartilage knee 10SE214", "disease state: osteoarthritis", "age: 82", "Sex: Female", "haplogroup: T", "82", "T", "Female" ], [ "22", "GSM1058115", "cartilage knee 10SE215", "disease state: osteoarthritis", "age: 76", "Sex: Female", "haplogroup: T", "76", "T", "Female" ], [ "23", "GSM1058116", "cartilage knee 10SE222", "disease state: osteoarthritis", "age: 65", "Sex: Female", "haplogroup: U", "65", "U", "Female" ] ];
var svgObjectNames   = [ "pca", "dens" ];

var cssText = ["stroke-width:1; stroke-opacity:0.4",
               "stroke-width:3; stroke-opacity:1" ];

// Global variables - these are set up below by 'reportinit'
var tables;             // array of all the associated ('tooltips') tables on the page
var checkboxes;         // the checkboxes
var ssrules;


function reportinit() 
{
 
    var a, i, status;

    /*--------find checkboxes and set them to start values------*/
    checkboxes = document.getElementsByName("ReportObjectCheckBoxes");
    if(checkboxes.length != highlightInitial.length)
	throw new Error("checkboxes.length=" + checkboxes.length + "  !=  "
                        + " highlightInitial.length="+ highlightInitial.length);
    
    /*--------find associated tables and cache their locations------*/
    tables = new Array(svgObjectNames.length);
    for(i=0; i<tables.length; i++) 
    {
        tables[i] = safeGetElementById("Tab:"+svgObjectNames[i]);
    }

    /*------- style sheet rules ---------*/
    var ss = document.styleSheets[0];
    ssrules = ss.cssRules ? ss.cssRules : ss.rules; 

    /*------- checkboxes[a] is (expected to be) of class HTMLInputElement ---*/
    for(a=0; a<checkboxes.length; a++)
    {
	checkboxes[a].checked = highlightInitial[a];
        status = checkboxes[a].checked; 
        setReportObj(a+1, status, false);
    }

}


function safeGetElementById(id)
{
    res = document.getElementById(id);
    if(res == null)
        throw new Error("Id '"+ id + "' not found.");
    return(res)
}

/*------------------------------------------------------------
   Highlighting of Report Objects 
 ---------------------------------------------------------------*/
function setReportObj(reportObjId, status, doTable)
{
    var i, j, plotObjIds, selector;

    if(doTable) {
	for(i=0; i<svgObjectNames.length; i++) {
	    showTipTable(i, reportObjId);
	} 
    }

    /* This works in Chrome 10, ssrules will be null; we use getElementsByClassName and loop over them */
    if(ssrules == null) {
	elements = document.getElementsByClassName("aqm" + reportObjId); 
	for(i=0; i<elements.length; i++) {
	    elements[i].style.cssText = cssText[0+status];
	}
    } else {
    /* This works in Firefox 4 */
    for(i=0; i<ssrules.length; i++) {
        if (ssrules[i].selectorText == (".aqm" + reportObjId)) {
		ssrules[i].style.cssText = cssText[0+status];
		break;
	    }
	}
    }

}

/*------------------------------------------------------------
   Display of the Metadata Table
  ------------------------------------------------------------*/
function showTipTable(tableIndex, reportObjId)
{
    var rows = tables[tableIndex].rows;
    var a = reportObjId - 1;

    if(rows.length != arrayMetadata[a].length)
	throw new Error("rows.length=" + rows.length+"  !=  arrayMetadata[array].length=" + arrayMetadata[a].length);

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = arrayMetadata[a][i];
}

function hideTipTable(tableIndex)
{
    var rows = tables[tableIndex].rows;

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = "";
}


/*------------------------------------------------------------
  From module 'name' (e.g. 'density'), find numeric index in the 
  'svgObjectNames' array.
  ------------------------------------------------------------*/
function getIndexFromName(name) 
{
    var i;
    for(i=0; i<svgObjectNames.length; i++)
        if(svgObjectNames[i] == name)
	    return i;

    throw new Error("Did not find '" + name + "'.");
}


/*------------------------------------------------------------
  SVG plot object callbacks
  ------------------------------------------------------------*/
function plotObjRespond(what, reportObjId, name)
{

    var a, i, status;

    switch(what) {
    case "show":
	i = getIndexFromName(name);
	showTipTable(i, reportObjId);
	break;
    case "hide":
	i = getIndexFromName(name);
	hideTipTable(i);
	break;
    case "click":
        a = reportObjId - 1;
	status = !checkboxes[a].checked;
	checkboxes[a].checked = status;
	setReportObj(reportObjId, status, true);
	break;
    default:
	throw new Error("Invalid 'what': "+what)
    }
}

/*------------------------------------------------------------
  checkboxes 'onchange' event
------------------------------------------------------------*/
function checkboxEvent(reportObjId)
{
    var a = reportObjId - 1;
    var status = checkboxes[a].checked;
    setReportObj(reportObjId, status, true);
}


/*------------------------------------------------------------
  toggle visibility
------------------------------------------------------------*/
function toggle(id){
  var head = safeGetElementById(id + "-h");
  var body = safeGetElementById(id + "-b");
  var hdtxt = head.innerHTML;
  var dsp;
  switch(body.style.display){
    case 'none':
      dsp = 'block';
      hdtxt = '-' + hdtxt.substr(1);
      break;
    case 'block':
      dsp = 'none';
      hdtxt = '+' + hdtxt.substr(1);
      break;
  }  
  body.style.display = dsp;
  head.innerHTML = hdtxt;
}
